import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

function corsHeaders(origin) {
  const allowedOrigins = [
    "*",
    "http://localhost:5174",
    "http://localhost:5173",
    "http://localhost:3000"
  ];
  const allowedOrigin = origin && allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400"
  };
}

function handleCors(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: corsHeaders(req.headers.get("origin"))
    });
  }
  return null;
}

function noContent(origin) {
  return new Response(null, {
    status: 204,
    headers: corsHeaders(origin)
  });
}

function json(body, init = 200, origin) {
  const base = typeof init === "number" ? {
    status: init
  } : init;
  return new Response(JSON.stringify(body), {
    ...base,
    headers: {
      "Content-Type": "application/json",
      ...corsHeaders(origin),
      ...base.headers || {}
    }
  });
}

function getEnv(name) {
  try {
    return Deno.env.get(name) || undefined;
  } catch  {
    return undefined;
  }
}

const supabaseUrl = getEnv("SUPABASE_URL");
const supabaseAnonKey = getEnv("SUPABASE_ANON_KEY");

if (!supabaseUrl || !supabaseAnonKey) {
  console.error("Missing SUPABASE_URL or SUPABASE_ANON_KEY");
}

const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: false
  }
});

async function handleLogout(req) {
  const origin = req.headers.get("origin");
  try {
    const body = await req.json().catch(()=>null);
    if (!body?.refreshToken) return json({
      error: "Invalid body"
    }, 400, origin);
    const { error } = await supabase.from("user_token").update({
      is_revoked: true
    }).eq("token_value", body.refreshToken);
    if (error) {
      console.error("logout update error", error.message);
      return noContent(origin);
    }
    return noContent(origin);
  } catch (e) {
    console.error("logout error", e);
    return noContent(origin);
  }
}

Deno.serve(async (req)=>{
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;
  const { pathname } = new URL(req.url);
  const isLogoutPath = pathname.endsWith("/logout") || pathname.endsWith("/") || pathname === "/";
  if (req.method === "POST" && isLogoutPath) {
    return await handleLogout(req);
  }
  return json({
    error: "Not found"
  }, 404, req.headers.get("origin"));
});

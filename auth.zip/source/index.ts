import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.47.10";
import * as jose from "npm:jose@5.9.3";
import bcrypt from "npm:bcryptjs@2.4.3";

function corsHeaders(origin) {
  const allowedOrigins = [
    "*",
    "http://localhost:5174",
    "http://localhost:5173",
    "http://localhost:3000"
  ];
  const allowedOrigin = origin && allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400"
  };
}

function handleCors(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: corsHeaders(req.headers.get("origin"))
    });
  }
  return null;
}

function json(body, init = 200, origin) {
  const base = typeof init === "number" ? {
    status: init
  } : init;
  return new Response(JSON.stringify(body), {
    ...base,
    headers: {
      "Content-Type": "application/json",
      ...corsHeaders(origin),
      ...base.headers || {}
    }
  });
}

function getRequiredEnv(names) {
  for (const name of names){
    const v = Deno.env.get(name);
    if (v) return v;
  }
  throw new Error(`Missing environment variable: one of ${names.join(", ")}`);
}

const supabaseUrl = getRequiredEnv([
  "SUPABASE_URL"
]);
const supabaseAnonKey = getRequiredEnv([
  "SUPABASE_ANON_KEY"
]);
const jwtSecret = getRequiredEnv([
  "SUPABASE_JWT_SECRET",
  "JWT_SECRET"
]);

const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: false
  }
});

async function handleLogin(req) {
  const origin = req.headers.get("origin");
  try {
    const { pathname } = new URL(req.url);
    if (req.method !== "POST" || !pathname.endsWith("/login")) {
      return json({
        error: "Not found"
      }, 404, origin);
    }
    const body = await req.json().catch(()=>null);
    if (!body || !body.email || !body.password) {
      return json({
        error: "Invalid body"
      }, 400, origin);
    }
    const ip = req.headers.get("x-forwarded-for") || req.headers.get("cf-connecting-ip") || "";
    const deviceInfo = req.headers.get("user-agent") || "";
    const { data: user, error } = await supabase.from("user_account").select("user_id, email, full_name, role, is_active, password_hash").eq("email", body.email).maybeSingle();
    if (error) return json({
      error: error.message
    }, 500, origin);
    if (!user) return json({
      error: "Invalid credentials"
    }, 401, origin);
    if (user.is_active === false) return json({
      error: "User disabled"
    }, 403, origin);
    const ok = await bcrypt.compare(body.password, user.password_hash);
    if (!ok) return json({
      error: "Invalid credentials"
    }, 401, origin);
    const now = Math.floor(Date.now() / 1000);
    const accessToken = await new jose.SignJWT({
      sub: user.user_id,
      email: user.email,
      name: user.full_name,
      roles: [
        user.role || "user"
      ]
    }).setProtectedHeader({
      alg: "HS256"
    }).setIssuedAt(now).setExpirationTime(now + 900).setIssuer("edge-function:auth").setAudience("authenticated").sign(new TextEncoder().encode(jwtSecret));
    const refreshToken = `${crypto.randomUUID()}-${jose.base64url.encode(crypto.getRandomValues(new Uint8Array(32)))}`;
    const expires = new Date(Date.now() + 1000 * 60 * 60 * 24 * 30);
    const { error: insertErr } = await supabase.from("user_token").insert({
      user_id: user.user_id,
      token_value: refreshToken,
      issued_at: new Date().toISOString(),
      expires_at: expires.toISOString(),
      is_revoked: false,
      device_info: deviceInfo,
      ip_address: ip
    });
    if (insertErr) return json({
      error: insertErr.message
    }, 500, origin);
    return json({
      accessToken,
      refreshToken,
      expiresIn: 900,
      user: {
        id: user.user_id,
        email: user.email,
        name: user.full_name,
        roles: [
          user.role || "user"
        ]
      }
    }, 200, origin);
  } catch (e) {
    console.error("auth/login error", e);
    const origin = req.headers.get("origin");
    return json({
      error: e instanceof Error ? e.message : "Unknown error"
    }, 500, origin);
  }
}

Deno.serve(async (req)=>{
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;
  const { pathname } = new URL(req.url);
  if (pathname.endsWith("/login")) {
    return await handleLogin(req);
  }
  return json({
    error: "Not found"
  }, 404, req.headers.get("origin"));
});
